<?php

    function sukses()
    {
        echo "<script>alert('Data berhasil dihapus.');
            window.location.href = 'readVendor.php';</script>";
    }

    function gagal()
    {
        echo "<script>alert('Gagal menghapus.');
            window.history.go(-1);</script>";
    }

    if(isset($_GET['id_vendor']))
    {
        $id_vendor = $_GET['id_vendor'];

        include "koneksi.php";

        $delete = mysqli_query($con, "DELETE FROM vendor WHERE id_vendor='$id_vendor'") or die (mysql_error());

        if($delete)
        {
            sukses();
        }
        else
        {
            gagal();
        }
    }
?>