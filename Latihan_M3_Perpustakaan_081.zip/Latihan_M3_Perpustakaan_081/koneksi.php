<?php
$host="localhost";
$db="perpustakaan_2021";
$user = "root";
$password="";


$con = mysqli_connect($host,$user,$password,$db);

// Check connection
if (mysqli_connect_errno()) {
    echo "Koneksi anda ke MySQL Gagal: " . mysqli_connect_error();
} else {
   // echo "Koneksi Berhasil!";
}
?>


