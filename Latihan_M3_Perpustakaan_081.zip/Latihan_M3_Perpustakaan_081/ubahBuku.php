<?php
function sukses()
{
    echo "<script>alert('Data berhasil diubah.');
            window.location.href = 'readBuku.php';</script>";
}

function gagal()
{
    echo "<script>alert('Gagal mengubah.');
            window.history.go(-1);</script>";
}

if(isset($_GET['id_buku']))
{
    $id_buku = $_GET['id_buku'];
    $name = $_POST['nama_buku']; 
    $id_jenis_buku = $_POST['idJenis']; // Mengambil nilai ID Jenis Buku dari combo box
    $id_vendor = $_POST['idVendor'];    // Mengambil nilai ID Vendor dari combo box
    $Stok = $_POST['jml_stok'];

    include "koneksi.php";

    // Gunakan parameterisasi untuk menghindari masalah karakter
    $check_query = mysqli_query($con, "SELECT * FROM buku WHERE id_buku = '$id_buku'");
    if (mysqli_num_rows($check_query) > 0) {
        // id ditemukan, jalankan perintah UPDATE dengan benar menutup tanda kutip di WHERE clause
        $update = "UPDATE buku SET nama_buku='$name', id_jenis_buku='$id_jenis_buku', id_vendor='$id_vendor', jml_stok='$Stok' WHERE id_buku = '$id_buku'";
        $result = mysqli_query($con, $update);
        if($result)
        {
            sukses();
        } else {
            gagal();
        }
    } else {
        gagal();
    }
}
?>
