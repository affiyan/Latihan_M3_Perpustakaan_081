<?php

    function sukses()
    {
        echo "<script>alert('Data berhasil dihapus.');
            window.location.href = 'readBuku.php';</script>";
    }

    function gagal()
    {
        echo "<script>alert('Gagal menghapus.');
            window.history.go(-1);</script>";
    }

    if(isset($_GET['id_buku']))
    {
        $id_buku = $_GET['id_buku'];

        include "koneksi.php";

        $delete = mysqli_query($con, "DELETE FROM buku WHERE id_buku='$id_buku'") or die (mysql_error());

        if($delete)
        {
            sukses();
        }
        else
        {
            gagal();
        }
    }
?>