<?php
   function sukses()
   {
       echo "<script>alert('Data berhasil diubah.');
           window.location.href = 'readJenis.php';</script>";
   }
   
   function gagal()
   {
       echo "<script>alert('Gagal mengubah.');
           window.history.go(-1);</script>";
   }
   
   if (isset($_GET['id_jenis_buku'])) {
       $id_jenis_buku = $_GET['id_jenis_buku'];    // Ambil ID jenis buku dari parameter URL
       $name = $_POST['nama'];                     // Ambil input teks
   
       include "koneksi.php";
   
       // Periksa apakah id tersebut ada dalam basis data sebelum update
       $check_query = mysqli_query($con, "SELECT * FROM jenis_buku WHERE id_jenis_buku = '$id_jenis_buku'");
       if (mysqli_num_rows($check_query) > 0) {
           // id ditemukan, jalankan perintah UPDATE
           $update = mysqli_query($con, "UPDATE jenis_buku SET nama_jenis_buku='$name' WHERE id_jenis_buku='$id_jenis_buku'");
   
           if ($update) {
               sukses();
           } else {
               gagal();
           }
       } else {
           // id tidak ditemukan dalam basis data
           echo "<script>alert('ID jenis buku tidak ditemukan.');
               window.history.go(-1);</script>";
       }
   }
   
?>
