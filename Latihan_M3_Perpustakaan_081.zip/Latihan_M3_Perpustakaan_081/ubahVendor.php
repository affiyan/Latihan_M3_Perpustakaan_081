<?php

    function sukses()
    {
        echo "<script>alert('Data berhasil diubah.');
            window.location.href = 'readVendor.php';</script>";
    }

    function gagal()
    {
        echo "<script>alert('Gagal mengubah.');
            window.history.go(-1);</script>";
    }

    if(isset($_GET['id_vendor']))
    {
        $id_vendor = $_GET['id_vendor'];
        $name = $_POST['nama']; //get input text
        $alamat = $_POST['alamatvendor']; //get input text
        $telp = $_POST['telp'];
        $email = $_POST['email'];


        include "koneksi.php";

        $update = mysqli_query($con, "UPDATE vendor set nama_vendor='$name', alamat_vendor='$alamat', telp_vendor='$telp' , email_vendor='$email' WHERE id_vendor='$id_vendor'") or die (mysql_error());

        if($update)
        {
            sukses();
        }
        else
        {
            gagal();
        }
    }
?>