<?php

    function sukses()
    {
        echo "<script>alert('Data berhasil dihapus.');
            window.location.href = 'readjenis.php';</script>";
    }

    function gagal()
    {
        echo "<script>alert('Gagal menghapus.');
            window.history.go(-1);</script>";
    }

    if(isset($_GET['id_jenis_buku']))
    {
        $id_jenis_buku = $_GET['id_jenis_buku'];

        include "koneksi.php";

        $delete = mysqli_query($con, "DELETE FROM jenis_buku WHERE id_jenis_buku='$id_jenis_buku'") or die (mysql_error());

        if($delete)
        {
            sukses();
        }
        else
        {
            gagal();
        }
    }
?>